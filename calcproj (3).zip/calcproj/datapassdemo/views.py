from django.shortcuts import render
from django.http import HttpResponse
def viewtemplate(request):
    return render(request,"datapassdemo/index.html",{"res":"Data passing","res1":[12,23,34],"res2":{"rno":1001,"name":"xyz"}})
'''
def templateview(request):
    if request.method=="POST":
        name = request.POST["txt"]  
        return HttpResponse("data is "+name)
    else:
        return render(request,"datapassdemo/demo.html")      
'''        
def templateview(request):
    return render(request,"datapassdemo/demo.html")   

def templateviewcode(request):
   name = request.GET["txt"]  
   return HttpResponse("data is "+name)      