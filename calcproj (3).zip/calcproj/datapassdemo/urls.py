from django.urls import path
from . import views
urlpatterns = [
    path('',views.viewtemplate,name='viewtemplate'),
    path('templateview',views.templateview,name='templateview'),
    path('templateviewcode',views.templateviewcode,name='templateviewcode')
]