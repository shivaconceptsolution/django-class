from django.apps import AppConfig


class MicalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mical'
