from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.views import View
from django.views.generic.edit import CreateView
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from django.urls import reverse
from .models import Job
class Add(View):
   def get(self,request): 
       return render(request,"addapp/addition.html")
   def post(self,request):    
      a = request.POST["txtnum1"]
      b = request.POST["txtnum2"]
      c = int(a)+int(b)
      return HttpResponse("Result is "+str(c))
   
class Prime(View):
    def get(self,request):
       return render(request,"addapp/prime.html")
    def post(self,request):    
        num = int(request.POST["txtnum"])
        s = ""
        for i in range(2,num):
            if num%i==0:
                s = "Not prime"
                break
        else:
             s = "prime"  
        return HttpResponse(s)           
class JobCreate(CreateView):
    model = Job
    fields = ['jobtitle', 'jobdescription']
    success_url = '/addapp/prime'
class JobList(ListView):
    model = Job  
class JobDetail(DetailView):
    model = Job    
class JobUpdate(UpdateView):
    model = Job    
    fields = ['jobtitle', 'jobdescription']
    success_url = '/addapp/joblist'
class JobDelete(DeleteView):
    model = Job 
    success_url = '/addapp/joblist'
def ajaxload(request):
    return render(request,"addapp/ajaxload.html")
def ajaxdata(request):
    data = request.GET["q"]
    res = Job.objects.filter(jobtitle__startswith=data)
    return render(request,"addapp/ajaxresult.html",{"key":res})                         