from django.urls import path
from addapp.views import Add,Prime,JobCreate,JobList,JobDetail,JobUpdate,JobDelete
from . import views
urlpatterns = [
    path('',Add.as_view()),
    path('prime',Prime.as_view()),
    path('job',JobCreate.as_view()),
    path('joblist',JobList.as_view()),
   # path('<pk>',JobDetail.as_view()),
    path('<pk>/jupdate',JobUpdate.as_view()),
    path('<pk>/jdelete',JobDelete.as_view()),
    path('ajaxload',views.ajaxload,name='ajaxload'),
    path('ajaxdata',views.ajaxdata,name='ajaxdata')
]