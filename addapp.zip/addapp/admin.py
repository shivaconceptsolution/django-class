from django.contrib import admin
from .models import Job
admin.site.register(Job)
# Register your models here.
