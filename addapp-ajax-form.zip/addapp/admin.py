from django.contrib import admin
from .models import Job,Reg
admin.site.register(Job)
admin.site.register(Reg)
# Register your models here.
