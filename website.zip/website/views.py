from django.shortcuts import render
from django.http import HttpResponse
def home(request):
    return render(request,"website/home.html")

def about(request):
    if request.method=="POST":
        name = request.POST["txtname"]
        gen = request.POST["gen"]
        btnsubmit = request.POST["btnsubmit"]
        course = request.POST.getlist("course")
        course1=""
        for c in course:
            course1 += c + " "
        country = request.POST["country"]
        state  = request.POST.getlist("state")
        state1=""
        for c in state:
            state1 += c + " "
        msg = request.POST["message"]    
        return render(request,"website/about.html",{"name":name,"gender":gen,"course":course1,"country":country,"state":state1,"message":msg,"btn":btnsubmit})    



    return render(request,"website/about.html")

def services(request):
    return render(request,"website/services.html")   

def gallery(request):
    return render(request,"website/gallery.html") 

def contact(request):
    if request.method=="POST":
        return HttpResponse("Welcome in Contact Form")
    return render(request,"website/contact.html")       

