from django.urls import path
from . import views
urlpatterns = [
    path('',views.viewtemplate,name='viewtemplate'),
    path('templateview',views.templateview,name='templateview'),
    path('templateviewcode',views.templateviewcode,name='templateviewcode'),
    path('passset',views.passset,name='passset'),
    path('passdata',views.passdata,name='passdata'),
    path('page1',views.page1,name='page1'),
    path('page2',views.page2,name='page2'),
    path('page22',views.page22,name='page22'),
    path('page3',views.page3,name='page3'),

]