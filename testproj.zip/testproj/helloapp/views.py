from django.shortcuts import render
from django.http import HttpResponse
def index(request):
    return HttpResponse("Hello World")

def addition(request):
    a,b = 100,2
    return HttpResponse("Result is "+str(a+b))
