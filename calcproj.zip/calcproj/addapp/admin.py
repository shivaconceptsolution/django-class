from django.contrib import admin
from .models import Job,Reg,Fupload
admin.site.register(Job)
admin.site.register(Reg)
admin.site.register(Fupload)
# Register your models here.
