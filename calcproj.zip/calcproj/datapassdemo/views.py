from django.shortcuts import render,redirect
from django.http import HttpResponse
def viewtemplate(request):
    return render(request,"datapassdemo/index.html",{"res":"Data passing","res1":[12,23,34],"res2":{"rno":1001,"name":"xyz"}})
'''
def templateview(request):
    if request.method=="POST":
        name = request.POST["txt"]  
        return HttpResponse("data is "+name)
    else:
        return render(request,"datapassdemo/demo.html")      
'''        
def templateview(request):
    return render(request,"datapassdemo/demo.html")   

def templateviewcode(request):
   name = request.GET["txt"]  
   return HttpResponse("data is "+name)      

def passset(request):
    return render(request,"datapassdemo/set.html",{'key':{1,3,4,5,6,9}})   

def passdata(request):
    if request.method=="POST":
        d = request.POST["txt"]
        return render(request,"datapassdemo/pass1.html",{'key':d})
    else:    
      return render(request,"datapassdemo/pass.html")    
def page1(request):
    return render(request,"datapassdemo/page1.html",)  
def page2(request):
    return render(request,"datapassdemo/page2.html",{"key1":request.GET["txt"]})      
def page3(request):
    if(request.GET.get("pg3")=="page22"): 
     return render(request,"datapassdemo/page1.html") 
    else: 
     return render(request,"datapassdemo/page3.html")          

def page22(request):
  
     return render(request,"datapassdemo/page2.html",{"key":"page22"})
    